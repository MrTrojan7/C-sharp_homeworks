var class_generalization_1_1_messenger =
[
    [ "SendMessage", "class_generalization_1_1_messenger.html#aa25e064b44bb0e915e884a558d300bc4", null ]
];