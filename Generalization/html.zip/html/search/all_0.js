var searchData=
[
  ['generalization',['Generalization',['../namespace_generalization.html',1,'']]]
];
