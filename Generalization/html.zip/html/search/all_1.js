var searchData=
[
  ['message',['Message',['../class_generalization_1_1_message.html',1,'Generalization']]],
  ['messenger',['Messenger',['../class_generalization_1_1_messenger.html',1,'Generalization']]]
];
