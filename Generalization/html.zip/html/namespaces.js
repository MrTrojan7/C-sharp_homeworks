var namespaces =
[
    [ "Generalization", "namespace_generalization.html", null ]
];