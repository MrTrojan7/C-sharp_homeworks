var class_generalization_1_1_message =
[
    [ "Message", "class_generalization_1_1_message.html#aa97491a473f33d288efb3524ea2ab4c0", null ],
    [ "Text", "class_generalization_1_1_message.html#a3dd920081666710719b236395cf77a10", null ]
];