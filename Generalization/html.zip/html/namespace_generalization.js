var namespace_generalization =
[
    [ "Message", "class_generalization_1_1_message.html", "class_generalization_1_1_message" ],
    [ "Messenger", "class_generalization_1_1_messenger.html", "class_generalization_1_1_messenger" ],
    [ "Person", "class_generalization_1_1_person.html", "class_generalization_1_1_person" ],
    [ "Point", "class_generalization_1_1_point.html", "class_generalization_1_1_point" ],
    [ "PrintArray", "class_generalization_1_1_print_array.html", null ],
    [ "Program", "class_generalization_1_1_program.html", null ]
];