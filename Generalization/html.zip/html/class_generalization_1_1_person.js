var class_generalization_1_1_person =
[
    [ "Person", "class_generalization_1_1_person.html#ac1fa8128c45fee90ff5076163299f9d8", null ],
    [ "Name", "class_generalization_1_1_person.html#adfe530658556dec74c4a13520b7c1417", null ]
];