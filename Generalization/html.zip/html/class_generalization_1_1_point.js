var class_generalization_1_1_point =
[
    [ "Point", "class_generalization_1_1_point.html#a7bf95ae4b10767aa8a45208f51309e4a", null ],
    [ "Point", "class_generalization_1_1_point.html#a055952aba15f4a02577d1af144829791", null ],
    [ "Print", "class_generalization_1_1_point.html#a64677a9aa85b1a27f61a40251303df17", null ],
    [ "x", "class_generalization_1_1_point.html#a4a199923e95fa2e07670dd978caa5a2e", null ],
    [ "y", "class_generalization_1_1_point.html#a364e128132a16a81915ee80ff7f00600", null ],
    [ "z", "class_generalization_1_1_point.html#ad59a6479fea0d2aa25bc90777d11b2a0", null ],
    [ "X", "class_generalization_1_1_point.html#a54dcd0e3482c3cb8d3626630754ac94f", null ],
    [ "Y", "class_generalization_1_1_point.html#a37a1e2e37d6e76a8f9c0127fc9582543", null ],
    [ "Z", "class_generalization_1_1_point.html#a91597fcd0387894157ba8bb95c29f7ea", null ]
];